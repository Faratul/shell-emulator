rmdir test VFS
